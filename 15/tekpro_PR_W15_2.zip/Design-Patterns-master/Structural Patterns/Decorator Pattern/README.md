# Decorator Pattern

``` Decorator pattern lets you attach new behaviors to objects by placing these objects inside special wrapper objects that contain the behaviors.```

### Links for Better Understanding

[https://www.youtube.com/watch?v=GCraGHx6gso](https://www.youtube.com/watch?v=GCraGHx6gso)

[https://refactoring.guru/design-patterns/decorator](https://refactoring.guru/design-patterns/decorator)