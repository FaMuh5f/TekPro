package Television;

public interface ITelevision {
    public void on();
    public void off();
    public void setChannel(int channel);
    public void setVolume(int volume);
}
