package Components;

public class Tuner {
    public void on() {}
    public void off() {}
}
