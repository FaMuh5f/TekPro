package Components;

public class Projector {
    public void on() {}
    public void off() {}
}
