package Components;

public class CdPlayer {
    public void on() {}
    public void off() {}
}
