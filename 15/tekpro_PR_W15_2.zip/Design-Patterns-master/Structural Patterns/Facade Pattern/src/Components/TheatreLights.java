package Components;

public class TheatreLights {
    public void on() {}
    public void off() {}
}
