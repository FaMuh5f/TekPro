package Components;

public class DvdPlayer {
    public void on() {}
    public void off() {}
    public void play(String movie) {}
}
