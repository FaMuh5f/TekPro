package Components;

public class PopcornPopper {
    public void pop() {}
    public void off() {}
}
