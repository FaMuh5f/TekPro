package Components;

public class Amplifier {
    public void on() {}
    public void off() {}
}
