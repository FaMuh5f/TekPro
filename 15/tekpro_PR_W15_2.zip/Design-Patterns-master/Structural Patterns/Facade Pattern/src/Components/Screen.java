package Components;

public class Screen {
    public void on() {}
    public void off() {}
}
