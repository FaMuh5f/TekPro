public interface IPlayer {
    void assignWeapon(String weapon);
}
