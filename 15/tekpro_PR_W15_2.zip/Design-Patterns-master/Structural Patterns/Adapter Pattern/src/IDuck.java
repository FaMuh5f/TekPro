public interface IDuck {
    void fly();
    void quack();
}
