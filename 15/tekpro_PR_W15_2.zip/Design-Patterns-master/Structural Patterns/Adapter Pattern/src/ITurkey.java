public interface ITurkey {
    void fly();
    void gobble();
}
