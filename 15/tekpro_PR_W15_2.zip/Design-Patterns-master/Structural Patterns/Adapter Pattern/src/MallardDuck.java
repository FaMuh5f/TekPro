public class MallardDuck implements IDuck {
    @Override
    public void fly() {

    }

    @Override
    public void quack() {

    }
}
