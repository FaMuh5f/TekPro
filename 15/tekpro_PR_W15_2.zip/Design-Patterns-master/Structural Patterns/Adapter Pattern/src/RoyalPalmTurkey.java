public class RoyalPalmTurkey implements ITurkey {
    @Override
    public void fly() {
        // Turkeys cannot fly that high
        // Very small height.
    }

    @Override
    public void gobble() {
        // Makes a gobbling noise.
    }
}
