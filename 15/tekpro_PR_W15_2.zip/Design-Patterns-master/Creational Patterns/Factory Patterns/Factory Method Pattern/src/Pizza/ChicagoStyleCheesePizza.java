package Pizza;

public class ChicagoStyleCheesePizza extends Pizza {
    public ChicagoStyleCheesePizza() {
        name = "NY Style Cheese Pizza.Pizza";
        dough = "Extra thick crust dough";
        sauce = "Tomato sauce";
        toppings.add("Mozzarella Cheese");
    }
}
