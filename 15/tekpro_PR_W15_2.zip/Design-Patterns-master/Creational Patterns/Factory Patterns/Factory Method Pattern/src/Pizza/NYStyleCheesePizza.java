package Pizza;

public class NYStyleCheesePizza extends Pizza{
    public NYStyleCheesePizza() {
        name = "NY Style Cheese Pizza";
        dough = "Thin crust dough";
        sauce = "Marinara sauce";
        toppings.add("Mozzarella Cheese");
    }
}
