# Abstract Factory Pattern

``` It lets you produce families of related objects without specifying their concrete classes.```

- In this pattern every method can be considered as a Factory Method.

### Links for Better Understanding

[https://www.youtube.com/watch?v=v-GiuMmsXj4](https://www.youtube.com/watch?v=v-GiuMmsXj4)
