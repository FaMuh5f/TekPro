package Ingredients.Interfaces;

public interface ICheese {
}
