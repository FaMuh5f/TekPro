package Ingredients.Classes;

import Ingredients.Interfaces.IDough;

public class ThinCrustDough implements IDough {
}
