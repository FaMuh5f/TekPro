package Ingredients.Interfaces;

public interface IVeggie {
}
