package Ingredients.Interfaces;

public interface IDough {
}
