package Ingredients.Classes;

import Ingredients.Interfaces.ICheese;

public class MozarrellaCheese implements ICheese {
}
