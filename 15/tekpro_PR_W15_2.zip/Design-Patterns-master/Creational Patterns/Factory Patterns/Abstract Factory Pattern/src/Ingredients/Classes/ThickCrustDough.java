package Ingredients.Classes;

import Ingredients.Interfaces.IDough;

public class ThickCrustDough implements IDough {
}
