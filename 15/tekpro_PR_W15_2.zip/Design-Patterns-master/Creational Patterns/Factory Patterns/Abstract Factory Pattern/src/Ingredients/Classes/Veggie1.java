package Ingredients.Classes;

import Ingredients.Interfaces.IVeggie;

public class Veggie1 implements IVeggie {
}
