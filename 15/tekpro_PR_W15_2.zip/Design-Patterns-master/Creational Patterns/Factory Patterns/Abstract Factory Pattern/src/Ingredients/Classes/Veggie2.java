package Ingredients.Classes;

import Ingredients.Interfaces.IVeggie;

public class Veggie2 implements IVeggie {
}
