package Ingredients.Classes;

import Ingredients.Interfaces.ISauce;

public class OnionGarlicSauce implements ISauce {
}
