# Singleton Pattern

``` It ensures that a class has only 1 instance and provide a global point of access to it.```

### Links for Better Understanding

[https://www.youtube.com/watch?v=hUE_j6q0LTQ](https://www.youtube.com/watch?v=hUE_j6q0LTQ)
