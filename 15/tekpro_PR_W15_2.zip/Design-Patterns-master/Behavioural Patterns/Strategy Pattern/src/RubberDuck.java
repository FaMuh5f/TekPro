// A duck that cannot fly and is made of rubber
public class RubberDuck extends Duck {
    @Override
    public void display() {

    }
}
