// It cannot fly
// It cannot quack
public class WoddenDuck extends Duck {
    @Override
    public void display() {

    }
}
