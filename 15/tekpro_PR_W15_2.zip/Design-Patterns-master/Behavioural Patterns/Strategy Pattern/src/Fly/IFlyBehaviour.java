package Fly;

public interface IFlyBehaviour {
    void fly();
}
