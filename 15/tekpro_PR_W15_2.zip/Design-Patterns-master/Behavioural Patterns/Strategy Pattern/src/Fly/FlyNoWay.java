package Fly;

public class FlyNoWay implements IFlyBehaviour {
    @Override
    public void fly() {
        // Cannot Fly
    }
}
