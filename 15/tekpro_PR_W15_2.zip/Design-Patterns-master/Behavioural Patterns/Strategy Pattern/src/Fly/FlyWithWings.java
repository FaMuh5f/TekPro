package Fly;

public class FlyWithWings implements IFlyBehaviour {
    @Override
    public void fly() {
        // Flying with wings
    }
}
