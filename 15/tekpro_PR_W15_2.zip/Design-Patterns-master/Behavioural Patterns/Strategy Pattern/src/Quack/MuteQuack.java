package Quack;

public class MuteQuack implements IQuackBehaviour {
    @Override
    public void quack() {
        // A different kinda quack ie mute
    }
}
