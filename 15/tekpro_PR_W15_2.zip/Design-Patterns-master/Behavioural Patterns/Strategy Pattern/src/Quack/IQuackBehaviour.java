package Quack;

public interface IQuackBehaviour {
    void quack();
}
