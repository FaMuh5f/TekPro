// Has a red head
// It can Fly
// It can quack
public class RedHeadDuck extends Duck {
    @Override
    public void display() {
    }
}
