public interface IShoppingElement {
    Double visit(IVisitor visitor);
}
