public interface IObserver {
    void update(double pressure, double temperature, double humidity);
}
