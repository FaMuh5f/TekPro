public class GraphNode {
}
