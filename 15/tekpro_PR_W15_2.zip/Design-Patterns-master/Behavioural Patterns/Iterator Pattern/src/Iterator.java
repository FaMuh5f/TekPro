public interface Iterator {
    boolean hasNext();
    GraphNode next();
}
