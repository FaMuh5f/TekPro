public interface IState {
    void insertQuarter();
    void ejectQuarter();
    void rotateCrank();
    void dispense();
}
