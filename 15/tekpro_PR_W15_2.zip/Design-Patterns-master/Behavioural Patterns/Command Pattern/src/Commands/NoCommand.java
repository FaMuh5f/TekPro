package Commands;

public class NoCommand implements ICommand {
    @Override
    public void execute() {
        // No operation Command
    }
}
