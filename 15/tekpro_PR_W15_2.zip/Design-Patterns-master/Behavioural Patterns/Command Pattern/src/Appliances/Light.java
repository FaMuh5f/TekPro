package Appliances;

public class Light {
}
