package Appliances;

public class Geyser {
}
